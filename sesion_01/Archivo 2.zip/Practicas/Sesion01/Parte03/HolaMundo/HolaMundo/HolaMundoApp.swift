//
//  HolaMundoApp.swift
//  HolaMundo
//
//  Created by Aula03 on 24/9/24.
//

import SwiftUI

@main
struct HolaMundoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
