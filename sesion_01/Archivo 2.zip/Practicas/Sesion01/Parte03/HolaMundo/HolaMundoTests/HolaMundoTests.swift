//
//  HolaMundoTests.swift
//  HolaMundoTests
//
//  Created by Aula03 on 24/9/24.
//

import Testing
@testable import HolaMundo

struct HolaMundoTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
